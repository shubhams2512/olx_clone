import React from "react";
import AppRouter from './config/router';


class App extends React.Component{
    render(){
        return(
            <AppRouter />
        );
    }
}

export default App;