

const set_data = () => {
    return (dispatch) => {
        dispatch({type: "SETDATA"})
    }
}

export {
    set_data
}   